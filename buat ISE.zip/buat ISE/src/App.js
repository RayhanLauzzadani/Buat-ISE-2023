import React, { Component } from "react";
import "./App.css";
import NavigationBar from "./Components/NavigationBar";
import "./style/landingPage.css";
import Intro from "./Components/Intro"

class App extends Component {
  render() {
    return (
      <div className="App container">
        
        /* awal Intro */
        <div className="cuy">
          <NavigationBar />
          <Intro />
        </div>
        /* akhir Intro */
        
        <div className="alert alert-info">
          <h3 className="alert alert-info">Halo aku Rayhan Lauzzadani</h3>
          <p className="subJudul">Pengen jadi bagian dari ISE!2023</p>
          <button className="mr-1 btn btn-success">Terima aku dong pls</button>
        </div>
      
      </div>
    );
  }
}

export default App;

import { Col, Container, Row } from "react-bootstrap"

const Intro = () => {
    return (
        <div className="Intro">
            <Container className="text-white text-center d-felx justify-content-center align-items-center">
              <Row>
                <Col>
                <div className="bx">WEB BUAT DAFTAR ISE2023!</div>
                </Col>
              </Row>
            </Container>
          </div>
    )
}

export default Intro
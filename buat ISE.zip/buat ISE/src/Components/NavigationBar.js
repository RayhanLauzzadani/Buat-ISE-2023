import { Navbar, Container, Nav } from "react-bootstrap"

const NavigationBar = () => {
    return (
        <div>
            <Navbar variant="dark">
                <Container>
                    <Navbar.Brand>SEMOGA KETERIMA ISE!20232023</Navbar.Brand>
                    <Nav>
                        <Nav.Link>HOBI</Nav.Link>
                        <Nav.Link>ANIME FAVORIT</Nav.Link>
                    </Nav>
                </Container>
            </Navbar>
        </div>
    )
}

export default NavigationBar





